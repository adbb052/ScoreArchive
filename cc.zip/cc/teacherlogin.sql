CREATE DATABASE IF NOT EXISTS teacherlogin DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE teacherlogin;

CREATE TABLE students (
  student_Id bigint(20) NOT NULL,
  forename varchar(20) NOT NULL,
  surname varchar(20) NOT NULL,
  age int(11) NOT NULL,
  postcode varchar(10) NOT NULL,
  biology_Grade int(11) NOT NULL,
  chemistry_Grade int(11) NOT NULL,
  physics_Grade int(11) NOT NULL,
  s_Id bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO students (student_Id, forename, surname, age, postcode, biology_Grade, chemistry_Grade, physics_Grade, s_Id) VALUES
(4634959633017255, 'dahir', 'noor', 21, 'SW2 8BE', 50, 50, 50, 4);

CREATE TABLE users (
  id bigint(20) NOT NULL,
  user_id bigint(20) NOT NULL,
  user_name varchar(50) NOT NULL,
  password varchar(50) NOT NULL,
  date timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO users (id, user_id, user_name, password, date) VALUES
(1, 4403572690689, 'test', '123', '2022-01-07 01:41:34');


ALTER TABLE students
  ADD PRIMARY KEY (s_Id),
  ADD KEY student_Id (student_Id),
  ADD KEY forename (forename),
  ADD KEY surname (surname),
  ADD KEY biology_Grade (biology_Grade),
  ADD KEY chemistry_Grade (chemistry_Grade),
  ADD KEY physics_Grade (physics_Grade);

ALTER TABLE users
  ADD PRIMARY KEY (id),
  ADD KEY user_id (user_id),
  ADD KEY date (date),
  ADD KEY user_name (user_name);


ALTER TABLE students
  MODIFY s_Id bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE users
  MODIFY id bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;